# Ember Launchpad

Minimal warm landing page starter.

Use this pack when you want:
- a product launch hero
- fast copy editing
- a visual tone that feels human instead of corporate
